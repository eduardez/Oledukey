# diymore242display
2.42" OLED Display from DIYMORE.CC . Kicad Footprints
LIB + footprint + 3D FILE


![alt text](https://github.com/ccadic/diymore242display/blob/master/Untitled2.JPG)
